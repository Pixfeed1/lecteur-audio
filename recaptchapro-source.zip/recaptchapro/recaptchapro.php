<?php
/**
 * 2007-2023 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2023 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class Recaptchapro extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'recaptchapro';
        $this->tab = 'front_office_features';
        $this->version = '1.4.0';
        $this->author = 'PrestaBucket';
        $this->need_instance = 1;
        $this->module_key = '3c8df6e2fdf1c6affd7486e46914c6fc';
        $this->author_address = '0x6DdE06869559a96eF9daeE09C83A398DE36A46F4';
        $this->tabb = (Tools::getIsset('atab') && Tools::getValue('atab')) ? Tools::getValue('atab') : 'configuration';

        // Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('CAPTCHA Google reCAPTCHA v3 PRO + anti Fake Accounts');
        $this->description =
        $this->l('Protect your Website from spam and abuse using an Advanced Risk Analysis Engine.');
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        // Load default values for backoffice settings
        $languages = Language::getLanguages(false);
        $values = [];

        foreach ($languages as $key => $lang) {
            if ($key == 0) {
                $values['RECAPTCHAPRO_WHITELISTMESSAGE'][$lang['id_lang']] = '';
            } else {
                $values['RECAPTCHAPRO_WHITELISTMESSAGE'][$lang['id_lang']] = '';
            }
        }

        Configuration::updateValue('RECAPTCHAPRO_SITE_KEY', '');
        Configuration::updateValue('RECAPTCHAPRO_SECRET_KEY', '');
        Configuration::updateValue('RECAPTCHAPRO_ENABLE_FOR', '1;4');
        Configuration::updateValue('RECAPTCHAPRO_FAIL_LOGINA', 0);
        Configuration::updateValue('RECAPTCHAPRO_RECAPTCHAV', 3);
        Configuration::updateValue('RECAPTCHAPRO_RETHEME', 'light');
        Configuration::updateValue('RECAPTCHAPRO_RELANGUAGE', 1);
        Configuration::updateValue('RECAPTCHAPRO_CUSTOMLANGUAGE', 'en');
        Configuration::updateValue('RECAPTCHAPRO_RESIZE', 'normal');
        Configuration::updateValue('RECAPTCHAPRO_POSITION', 'inline');
        Configuration::updateValue('RECAPTCHAPRO_THRESHOLD', 0.5);

        // Include install core where we install database tables
        include dirname(__FILE__) . '/sql/install.php';

        // Check if PrestaShop version is 8+ in order to set correct Hooks
        if (Tools::substr(_PS_VERSION_, 0, 1) == '8') {
            return parent::install()
                && $this->registerHook('header')
                && $this->registerHook('displayBackOfficeHeader')
                && $this->registerHook('actionAdminLoginControllerSetMedia')
                && $this->registerHook('actionDispatcher')
                && $this->registerHook('createAccountForm');
        } else {
            return parent::install()
                && $this->registerHook('header')
                && $this->registerHook('backOfficeHeader')
                && $this->registerHook('actionAdminLoginControllerSetMedia')
                && $this->registerHook('actionDispatcher')
                && $this->registerHook('createAccountForm');
        }
    }

    public function uninstall()
    {
        Configuration::deleteByName('RECAPTCHAPRO_SITE_KEY');
        Configuration::deleteByName('RECAPTCHAPRO_SECRET_KEY');
        Configuration::deleteByName('RECAPTCHAPRO_ENABLE_FOR');
        Configuration::deleteByName('RECAPTCHAPRO_FAIL_LOGINA');
        Configuration::deleteByName('RECAPTCHAPRO_RECAPTCHAV');
        Configuration::deleteByName('RECAPTCHAPRO_RETHEME');
        Configuration::deleteByName('RECAPTCHAPRO_RELANGUAGE');
        Configuration::deleteByName('RECAPTCHAPRO_CUSTOMLANGUAGE');
        Configuration::deleteByName('RECAPTCHAPRO_RESIZE');
        Configuration::deleteByName('RECAPTCHAPRO_WHITELISTMESSAGE');
        Configuration::deleteByName('RECAPTCHAPRO_POSITION');
        Configuration::deleteByName('RECAPTCHAPRO_THRESHOLD');

        include dirname(__FILE__) . '/sql/uninstall.php';

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        $url = Tools::getHttpHost(true) . $_SERVER['REQUEST_URI'] . '&atab=recaptchapro';
        $url = Tools::substr($url, 0, strpos($url, '&atab='));

        $this->context->smarty->assign('module_dir', Tools::getProtocol(Tools::usingSecureMode())
        . $_SERVER['HTTP_HOST'] . $this->getPathUri());
        $this->context->smarty->assign('module_link', $url);
        $this->context->smarty->assign('documentation_url', Tools::getHttpHost(true) . __PS_BASE_URI__);
        $this->context->smarty->assign('documentation_lg', in_array($this->context->language->iso_code, ['de', 'en', 'es', 'fr', 'it', 'nl', 'pl', 'pt', 'ru']) ? $this->context->language->iso_code : 'en');
        $this->context->smarty->assign('tab', $this->tabb);
        $this->context->smarty->assign('uri', $this->getPathUri());
        $this->context->smarty->assign('ajax_token', Tools::getAdminToken('AdminModules'));
        $this->context->smarty->assign('version', Tools::substr(_PS_VERSION_, 0, 3));
        $this->context->smarty->assign('version_explicit', Tools::substr(_PS_VERSION_, 0, 5));
        $this->context->smarty->assign('version_explicit_one', Tools::substr(_PS_VERSION_, 0, 1));
        $this->context->smarty->assign('created_by_l', $this->l('Created by'));
        $this->context->smarty->assign('module_version_f', $this->version);
        $this->context->smarty->assign('current_version_l', $this->l('Current version'));
        $this->context->smarty->assign('rate_us_l', $this->l('Rate us'));
        $this->context->smarty->assign('documentation_l', $this->l('Documentation'));
        $this->context->smarty->assign('need_help_l', $this->l('Need help'));

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');
        $endput = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/admin_footer.tpl');

        // Productsheet tab functionality
        if ($this->tabb == 'whitelist') {
            if (Tools::isSubmit('delete' . $this->name)) {
                if (Tools::getIsset('id_whitelist')) {
                    $this->deleteWhitelist(Tools::getValue('id_whitelist'));
                }

                return $this->displayConfirmation($this->l('Settings saved successfully.')) .
                    $output . $this->displayList() . $endput;
            }
        }

        // If values have been submitted in the form, process.
        if (((bool) Tools::isSubmit('submitRecaptchaproModule')) == true) {
            if ($this->tabb == 'configuration') {
                return $this->postProcess() . $output . $this->renderForm() . $endput;
            } elseif ($this->tabb == 'whitelist') {
                return $output . $this->displayList() . $endput;
            }
        } else {
            if ($this->tabb == 'configuration') {
                return $output . $this->renderForm() . $endput;
            } elseif ($this->tabb == 'whitelist') {
                if (Tools::getIsset('re_successfully')) {
                    return $this->displayConfirmation($this->l('Settings saved successfully.')) .
                        $output . $this->displayList() . $endput;
                } else {
                    return $output . $this->displayList() . $endput;
                }
            }
        }
    }

    /**
     * Create the Helper List
     */
    public function displayList()
    {
        $sql = 'SELECT id_whitelist, ip_address, date_added FROM ' . _DB_PREFIX_ . 'rec_whitelist';

        if (Tools::getValue('submitFilter' . $this->name)) {
            if (Tools::getValue($this->name . 'Filter_ip_address')) {
                $sql .= ' WHERE ip_address LIKE "%' . pSQL(Tools::getValue($this->name . 'Filter_ip_address')) . '%"';
            }
        }

        $sql .= ' ORDER BY id_whitelist DESC';

        $result = Db::getInstance()->ExecuteS($sql);

        $this->fields_list = [
            'ip_address' => [
                'title' => $this->l('IP address'),
                'type' => 'text',
            ],
            'date_added' => [
                'title' => $this->l('Date added'),
                'search' => false,
            ],
        ];

        $helper = new HelperList();
        $helper->shopLinkType = '';
        $helper->simple_header = false;
        $helper->identifier = 'id_whitelist';
        $helper->show_toolbar = true;
        $helper->listTotal = count($result);
        $helper->toolbar_btn['new'] = [
            'desc' => $this->l('Add IP address to Whitelist'),
            'class' => 'rec-add-ip-whitelist',
        ];
        $helper->title = $this->l('Whitelist');
        $helper->table = $this->name;
        $helper->actions = ['delete'];
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex .
        '&configure=' . $this->name . '&token=' .
        Tools::getAdminTokenLite('AdminModules') . '&atab=whitelist';

        return $helper->generateList($result, $this->fields_list);
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitRecaptchaproModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = [
            'uri' => $this->getPathUri(),
            'fields_value' => $this->getConfigFormValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        ];

        return $helper->generateForm([$this->getConfigForm()]);
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        $captcha_m1 = $this->l('This message will be displayed instead of the ReCaptcha');
        $captcha_m2 = $this->l(' in all forms except the Registration form. Leave empty for nothing.');

        $fail_captcha1 = $this->l('How many fail logins it will take the captcha');
        $fail_captcha2 = $this->l(' to be displayed. Enter 0 for instant display.');

        $language_array = [
            ['key' => 'ar', 'name' => $this->l('Arabic')],
            ['key' => 'af', 'name' => $this->l('Afrikaans')],
            ['key' => 'am', 'name' => $this->l('Amharic')],
            ['key' => 'hy', 'name' => $this->l('Armenian')],
            ['key' => 'az', 'name' => $this->l('Azerbaijani')],
            ['key' => 'eu', 'name' => $this->l('Basque')],
            ['key' => 'bn', 'name' => $this->l('Bengali')],
            ['key' => 'bg', 'name' => $this->l('Bulgarian')],
            ['key' => 'ca', 'name' => $this->l('Catalan')],
            ['key' => 'zh-HK', 'name' => $this->l('Chinese (Hong Kong)')],
            ['key' => 'zh-CN', 'name' => $this->l('Chinese (Simplified)')],
            ['key' => 'zh-TW', 'name' => $this->l('Chinese (Traditional)')],
            ['key' => 'hr', 'name' => $this->l('Croatian')],
            ['key' => 'cs', 'name' => $this->l('Czech')],
            ['key' => 'da', 'name' => $this->l('Danish')],
            ['key' => 'nl', 'name' => $this->l('Dutch')],
            ['key' => 'en-GB', 'name' => $this->l('English (UK)')],
            ['key' => 'en', 'name' => $this->l('English (US)')],
            ['key' => 'et', 'name' => $this->l('Estonian')],
            ['key' => 'fil', 'name' => $this->l('Filipino')],
            ['key' => 'fi', 'name' => $this->l('Finnish')],
            ['key' => 'fr', 'name' => $this->l('French')],
            ['key' => 'fr-CA', 'name' => $this->l('French (Canadian)')],
            ['key' => 'gl', 'name' => $this->l('Galician')],
            ['key' => 'ka', 'name' => $this->l('Georgian')],
            ['key' => 'de', 'name' => $this->l('German')],
            ['key' => 'de-AT', 'name' => $this->l('German (Austria)')],
            ['key' => 'de-CH', 'name' => $this->l('German (Switzerland)')],
            ['key' => 'el', 'name' => $this->l('Greek')],
            ['key' => 'gu', 'name' => $this->l('Gujarati')],
            ['key' => 'iw', 'name' => $this->l('Hebrew')],
            ['key' => 'hi', 'name' => $this->l('Hindi')],
            ['key' => 'hu', 'name' => $this->l('Hungarian')],
            ['key' => 'is', 'name' => $this->l('Icelandic')],
            ['key' => 'id', 'name' => $this->l('Indonesian')],
            ['key' => 'it', 'name' => $this->l('Italian')],
            ['key' => 'ja', 'name' => $this->l('Japanese')],
            ['key' => 'kn', 'name' => $this->l('Kannada')],
            ['key' => 'ko', 'name' => $this->l('Korean')],
            ['key' => 'lo', 'name' => $this->l('Laothian')],
            ['key' => 'lv', 'name' => $this->l('Latvian')],
            ['key' => 'lt', 'name' => $this->l('Lithuanian')],
            ['key' => 'ms', 'name' => $this->l('Malay')],
            ['key' => 'ml', 'name' => $this->l('Malayalam')],
            ['key' => 'mr', 'name' => $this->l('Marathi')],
            ['key' => 'mn', 'name' => $this->l('Mongolian')],
            ['key' => 'no', 'name' => $this->l('Norwegian')],
            ['key' => 'fa', 'name' => $this->l('Persian')],
            ['key' => 'pl', 'name' => $this->l('Polish')],
            ['key' => 'pt', 'name' => $this->l('Portuguese')],
            ['key' => 'pt-BR', 'name' => $this->l('Portuguese (Brazil)')],
            ['key' => 'pt-PT', 'name' => $this->l('Portuguese (Portugal)')],
            ['key' => 'ro', 'name' => $this->l('Romanian')],
            ['key' => 'ru', 'name' => $this->l('Russian')],
            ['key' => 'sr', 'name' => $this->l('Serbian')],
            ['key' => 'si', 'name' => $this->l('Sinhalese')],
            ['key' => 'sk', 'name' => $this->l('Slovak')],
            ['key' => 'sl', 'name' => $this->l('Slovenian')],
            ['key' => 'es', 'name' => $this->l('Spanish')],
            ['key' => 'es-419', 'name' => $this->l('Spanish (Latin America)')],
            ['key' => 'sw', 'name' => $this->l('Swahili')],
            ['key' => 'sv', 'name' => $this->l('Latvian')],
            ['key' => 'ta', 'name' => $this->l('Tamil')],
            ['key' => 'te', 'name' => $this->l('Telugu')],
            ['key' => 'th', 'name' => $this->l('Thai')],
            ['key' => 'tr', 'name' => $this->l('Turkish')],
            ['key' => 'uk', 'name' => $this->l('Ukrainian')],
            ['key' => 'ur', 'name' => $this->l('Urdu')],
            ['key' => 'vi', 'name' => $this->l('Vietnamese')],
            ['key' => 'zu', 'name' => $this->l('Zulu')],
        ];

        if (Tools::substr(_PS_VERSION_, 0, 3) == '1.5') {
            return [
                'form' => [
                    'legend' => [
                    'title' => $this->l('Configuration'),
                    'icon' => 'icon-cogs',
                    ],
                    'input' => [
                        [
                            'type' => 'text',
                            'label' => $this->l('Site Key'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_SITE_KEY',
                            'class' => 'resitekey',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Secret Key'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_SECRET_KEY',
                            'class' => 'resecretkey',
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('Enable ReCaptcha for'),
                            'name' => 'RECAPTCHAPRO_ENABLE_FOR[]',
                            'multiple' => true,
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Contact form')],
                                    ['key' => '3', 'name' => $this->l('Frontend login form')],
                                    ['key' => '4', 'name' => $this->l('Registration form')],
                                    ['key' => '5', 'name' => $this->l('Reset password form')],
                                    ['key' => '6', 'name' => $this->l('Comments form')],
                                    ['key' => '7', 'name' => $this->l('Newsletter form')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                            'class' => 'enablefor_re',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Show ReCaptcha after fail customer login attempts'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_FAIL_LOGINA',
                            'class' => 'faillogina',
                            'desc' => $fail_captcha1 . $fail_captcha2,
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha version'),
                            'name' => 'RECAPTCHAPRO_RECAPTCHAV',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Version 2 Checkbox')],
                                    ['key' => '2', 'name' => $this->l('Version 2 Invisible')],
                                    ['key' => '3', 'name' => $this->l('Version 3')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha theme'),
                            'name' => 'RECAPTCHAPRO_RETHEME',
                            'class' => 'retheme_db',
                            'options' => [
                                'query' => [
                                    ['key' => 'light', 'name' => $this->l('Light')],
                                    ['key' => 'dark', 'name' => $this->l('Dark')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha language'),
                            'name' => 'RECAPTCHAPRO_RELANGUAGE',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Default shop language')],
                                    ['key' => '2', 'name' => $this->l('Select custom language')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                            'desc' => $this->l('Default language work with multilanguage too.'),
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('Custom language'),
                            'name' => 'RECAPTCHAPRO_CUSTOMLANGUAGE',
                            'class' => 'customlanguage_db',
                            'options' => [
                                'query' => $language_array,
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha size'),
                            'name' => 'RECAPTCHAPRO_RESIZE',
                            'options' => [
                                'query' => [
                                    ['key' => 'normal', 'name' => $this->l('Normal')],
                                    ['key' => 'compact', 'name' => $this->l('Compact')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha position'),
                            'name' => 'RECAPTCHAPRO_POSITION',
                            'options' => [
                                'query' => [
                                    ['key' => 'inline', 'name' => $this->l('Inline')],
                                    ['key' => 'right', 'name' => $this->l('Bottom right')],
                                    ['key' => 'left', 'name' => $this->l('Bottom left')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'rangeslider',
                            'label' => $this->l('reCaptcha threshold'),
                            'name' => 'RECAPTCHAPRO_THRESHOLD',
                            'class' => 'r_threshold',
                            'version' => '1.5',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Whitelist message'),
                            'desc' => $captcha_m1 . $captcha_m2,
                            'name' => 'RECAPTCHAPRO_WHITELISTMESSAGE',
                            'lang' => true,
                        ],
                    ],
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                ],
            ];
        } else {
            return [
                'form' => [
                    'legend' => [
                    'title' => $this->l('Configuration'),
                    'icon' => 'icon-cogs',
                    ],
                    'input' => [
                        [
                            'type' => 'text',
                            'label' => $this->l('Site Key'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_SITE_KEY',
                            'class' => 'resitekey',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Secret Key'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_SECRET_KEY',
                            'class' => 'resecretkey',
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('Enable ReCaptcha for'),
                            'name' => 'RECAPTCHAPRO_ENABLE_FOR[]',
                            'multiple' => true,
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Contact form')],
                                    ['key' => '2', 'name' => $this->l('Backend Login form')],
                                    ['key' => '3', 'name' => $this->l('Frontend login form')],
                                    ['key' => '4', 'name' => $this->l('Registration form')],
                                    ['key' => '5', 'name' => $this->l('Reset password form')],
                                    ['key' => '6', 'name' => $this->l('Comments form')],
                                    ['key' => '7', 'name' => $this->l('Newsletter form')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                            'class' => 'enablefor_re',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Show ReCaptcha after fail customer login attempts'),
                            'required' => true,
                            'name' => 'RECAPTCHAPRO_FAIL_LOGINA',
                            'class' => 'faillogina',
                            'desc' => $fail_captcha1 . $fail_captcha2,
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha version'),
                            'name' => 'RECAPTCHAPRO_RECAPTCHAV',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Version 2 Checkbox')],
                                    ['key' => '2', 'name' => $this->l('Version 2 Invisible')],
                                    ['key' => '3', 'name' => $this->l('Version 3')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        Configuration::get('RECAPTCHAPRO_RECAPTCHAV') == 1 ?
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha theme'),
                            'name' => 'RECAPTCHAPRO_RETHEME',
                            'class' => 'retheme_db',
                            'options' => [
                                'query' => [
                                    ['key' => 'light', 'name' => $this->l('Light')],
                                    ['key' => 'dark', 'name' => $this->l('Dark')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ] : [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha theme'),
                            'name' => 'RECAPTCHAPRO_RETHEME',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => 'no-input'],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha language'),
                            'name' => 'RECAPTCHAPRO_RELANGUAGE',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => $this->l('Default shop language')],
                                    ['key' => '2', 'name' => $this->l('Select custom language')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                            'desc' => $this->l('Default language work with multilanguage too.'),
                        ],
                        Configuration::get('RECAPTCHAPRO_RELANGUAGE') == 2 ?
                        [
                            'type' => 'select',
                            'label' => $this->l('Custom language'),
                            'name' => 'RECAPTCHAPRO_CUSTOMLANGUAGE',
                            'class' => 'customlanguage_db',
                            'options' => [
                                'query' => $language_array,
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ] : [
                            'type' => 'select',
                            'label' => $this->l('Custom language'),
                            'name' => 'RECAPTCHAPRO_CUSTOMLANGUAGE',
                            'options' => [
                                'query' => $language_array,
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        Configuration::get('RECAPTCHAPRO_RECAPTCHAV') == 1 ?
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha size'),
                            'name' => 'RECAPTCHAPRO_RESIZE',
                            'options' => [
                                'query' => [
                                    ['key' => 'normal', 'name' => $this->l('Normal')],
                                    ['key' => 'compact', 'name' => $this->l('Compact')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ] : [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha size'),
                            'name' => 'RECAPTCHAPRO_RESIZE',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => 'no-input'],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        Configuration::get('RECAPTCHAPRO_RECAPTCHAV') == 2 || Configuration::get('RECAPTCHAPRO_RECAPTCHAV') == 3 ?
                        [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha position'),
                            'name' => 'RECAPTCHAPRO_POSITION',
                            'options' => [
                                'query' => [
                                    ['key' => 'inline', 'name' => $this->l('Inline')],
                                    ['key' => 'right', 'name' => $this->l('Bottom right')],
                                    ['key' => 'left', 'name' => $this->l('Bottom left')],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ] : [
                            'type' => 'select',
                            'label' => $this->l('reCaptcha position'),
                            'name' => 'RECAPTCHAPRO_POSITION',
                            'options' => [
                                'query' => [
                                    ['key' => '1', 'name' => 'no-input'],
                                ],
                                'id' => 'key',
                                'name' => 'name',
                            ],
                        ],
                        [
                            'type' => 'rangeslider',
                            'label' => $this->l('reCaptcha threshold'),
                            'name' => 'RECAPTCHAPRO_THRESHOLD',
                            'class' => 'r_threshold',
                            'version' => 'n1.5',
                        ],
                        [
                            'type' => 'text',
                            'label' => $this->l('Whitelist message'),
                            'desc' => $captcha_m1 . $captcha_m2,
                            'name' => 'RECAPTCHAPRO_WHITELISTMESSAGE',
                            'lang' => true,
                        ],
                    ],
                    'submit' => [
                        'title' => $this->l('Save'),
                    ],
                ],
            ];
        }
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        $languages = Language::getLanguages(false);
        $fields = [];

        foreach ($languages as $lang) {
            $fields['RECAPTCHAPRO_WHITELISTMESSAGE'][$lang['id_lang']] =
            Configuration::get('RECAPTCHAPRO_WHITELISTMESSAGE', $lang['id_lang']);
        }

        $fields['RECAPTCHAPRO_ENABLE_FOR[]'] = explode(';', Configuration::get('RECAPTCHAPRO_ENABLE_FOR'));

        $fields['RECAPTCHAPRO_SITE_KEY'] = Configuration::get('RECAPTCHAPRO_SITE_KEY');
        $fields['RECAPTCHAPRO_SECRET_KEY'] = Configuration::get('RECAPTCHAPRO_SECRET_KEY');
        $fields['RECAPTCHAPRO_FAIL_LOGINA'] = Configuration::get('RECAPTCHAPRO_FAIL_LOGINA');
        $fields['RECAPTCHAPRO_RECAPTCHAV'] = Configuration::get('RECAPTCHAPRO_RECAPTCHAV');
        $fields['RECAPTCHAPRO_RETHEME'] = Configuration::get('RECAPTCHAPRO_RETHEME');
        $fields['RECAPTCHAPRO_RELANGUAGE'] = Configuration::get('RECAPTCHAPRO_RELANGUAGE');
        $fields['RECAPTCHAPRO_CUSTOMLANGUAGE'] = Configuration::get('RECAPTCHAPRO_CUSTOMLANGUAGE');
        $fields['RECAPTCHAPRO_POSITION'] = Configuration::get('RECAPTCHAPRO_POSITION');
        $fields['RECAPTCHAPRO_THRESHOLD'] = Configuration::get('RECAPTCHAPRO_THRESHOLD');
        $fields['RECAPTCHAPRO_RESIZE'] = Configuration::get('RECAPTCHAPRO_RESIZE');

        return $fields;
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $errors = [];
        $values = [];

        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            $languages = Language::getLanguages(false);
            // Language distribuitor
            if ($key == 'RECAPTCHAPRO_WHITELISTMESSAGE') {
                foreach ($languages as $lang) {
                    $values[$key][$lang['id_lang']] = Tools::getValue($key . '_' . $lang['id_lang']);
                }

                Configuration::updateValue($key, $values[$key]);
            } elseif ($key == 'RECAPTCHAPRO_SITE_KEY') {
                if (!Tools::getValue($key) && trim(Tools::strlen(Tools::getValue($key)) < 1)) {
                    $errors['site_key'] = $this->l('Site Key field can not be empty. Field required.');
                } else {
                    Configuration::updateValue($key, Tools::getValue($key));
                }
            } elseif ($key == 'RECAPTCHAPRO_SECRET_KEY') {
                if (!Tools::getValue($key) && trim(Tools::strlen(Tools::getValue($key)) < 1)) {
                    $errors['secret_key'] = $this->l('Secret Key field can not be empty. Field required.');
                } else {
                    Configuration::updateValue($key, Tools::getValue($key));
                }
            } elseif ($key == 'RECAPTCHAPRO_FAIL_LOGINA') {
                if (!Tools::getValue($key) && trim(Tools::strlen(Tools::getValue($key)) < 1)) {
                    $errors['fail_logina'] = 'Login attemps field can not be empty. Field required.';
                } elseif (!is_numeric(Tools::getValue($key))) {
                    $errors['fail_logina'] = 'Login attemps field can be only a number.';
                } else {
                    Configuration::updateValue($key, Tools::getValue($key));
                }
            } elseif ($key == 'RECAPTCHAPRO_ENABLE_FOR[]') {
                if (Tools::getValue('RECAPTCHAPRO_ENABLE_FOR')) {
                    $implode_r = implode(';', Tools::getValue('RECAPTCHAPRO_ENABLE_FOR'));
                    Configuration::updateValue('RECAPTCHAPRO_ENABLE_FOR', $implode_r);
                } else {
                    Configuration::updateValue('RECAPTCHAPRO_ENABLE_FOR', '');
                }
            } else {
                Configuration::updateValue($key, Tools::getValue($key));
            }
        }

        if ($errors) {
            $this->_clearCache('footer.tpl');
            return $this->displayError(implode('<br>', $errors));
        } else {
            $this->_clearCache('footer.tpl');
            return $this->displayConfirmation($this->l('Settings saved successfully.'));
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookBackOfficeHeader()
    {
        if ((Tools::getValue('controller') == 'AdminProducts' && Tools::getValue('id_product'))
            || (Tools::getValue('controller') == 'AdminModules'
            && (Tools::getValue('configure') == $this->name
            || Tools::getValue('module_name') == $this->name))) {
            if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                Media::addJsDef(
                    [
                        'l_light' => $this->l('Light'),
                        'l_dark' => $this->l('Dark'),
                        'l_normal' => $this->l('Normal'),
                        'l_compact' => $this->l('Compact'),
                        'l_right' => $this->l('Bottom right'),
                        'l_left' => $this->l('Bottom left'),
                        'l_inline' => $this->l('Inline'),
                    ]
                );
            }

            $this->context->controller->addCSS($this->_path . 'views/css/back.css');

            // Add new Style & Colors to Backoffice from PrestaShop 8.x +
            if (Tools::substr(_PS_VERSION_, 0, 1) == '8') {
                $this->context->controller->addCSS($this->_path . 'views/css/back_black.css');
            }

            if (Tools::substr(_PS_VERSION_, 0, 3) == '1.5') {
                $this->context->controller->addCSS($this->_path . 'views/css/back15.css');
            } else {
                $this->context->controller->addJS($this->_path . 'views/js/back.js');
            }
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookDisplayHeader()
    {
        // Prepeare each section for display
        $captcha_enable = explode(';', Configuration::get('RECAPTCHAPRO_ENABLE_FOR'));
        $captcha_contact = false;
        $captcha_frontend = false;
        $captcha_registration = false;
        $captcha_resetp = false;
        $captcha_comments = false;
        $captcha_newsletter = false;

        foreach ($captcha_enable as $each_e) {
            switch ($each_e) {
                case 1:
                    $captcha_contact = true;
                    break;
                case 3:
                    $captcha_frontend = true;
                    break;
                case 4:
                    $captcha_registration = true;
                    break;
                case 5:
                    $captcha_resetp = true;
                    break;
                case 6:
                    $captcha_comments = true;
                    break;
                case 7:
                    $captcha_newsletter = true;
                    break;
            }
        }

        // Add all Javascript global variables
        if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
            Media::addJsDef(
                [
                    'there_is1' => $this->l('There is 1 error'),
                    'wrong_captcha' => $this->l('Wrong captcha.'),
                    'check_bellow' => $this->l('Please check below:'),
                    'validate_first' => $this->l('I am not a robot then click again on subscribe'),
                    'site_key' => Configuration::get('RECAPTCHAPRO_SITE_KEY'),
                    'whitelisted' => $this->checkIfWhitelisted(),
                    'whitelist_m' => Configuration::get('RECAPTCHAPRO_WHITELISTMESSAGE', $this->context->language->id),
                    're_version' => Configuration::get('RECAPTCHAPRO_RECAPTCHAV'),
                    'p_version' => Tools::substr(_PS_VERSION_, 0, 3),
                    'p_version_short' => Tools::substr(_PS_VERSION_, 0, 1),
                    're_theme' => Configuration::get('RECAPTCHAPRO_RETHEME'),
                    're_size' => Configuration::get('RECAPTCHAPRO_RESIZE'),
                    're_position' => Configuration::get('RECAPTCHAPRO_POSITION'),
                ]
            );
        } else {
            $this->context->smarty->assign(
                [
                    'there_is1' => $this->l('There is 1 error'),
                    'wrong_captcha' => $this->l('Wrong captcha.'),
                    'check_bellow' => $this->l('Please check below:'),
                    'validate_first' => $this->l('I am not a robot then click again on subscribe'),
                    'site_key' => Configuration::get('RECAPTCHAPRO_SITE_KEY'),
                    'whitelisted' => $this->checkIfWhitelisted(),
                    'whitelist_m' => Configuration::get('RECAPTCHAPRO_WHITELISTMESSAGE', $this->context->language->id),
                    're_version' => Configuration::get('RECAPTCHAPRO_RECAPTCHAV'),
                    'p_version' => Tools::substr(_PS_VERSION_, 0, 3),
                    're_theme' => Configuration::get('RECAPTCHAPRO_RETHEME'),
                    're_size' => Configuration::get('RECAPTCHAPRO_RESIZE'),
                    're_position' => Configuration::get('RECAPTCHAPRO_POSITION'),
                ]
            );
        }

        // Check and display captcha newsletter Javascript
        if ($captcha_newsletter) {
            $this->loadRecaptchaAssets();
            $this->context->controller->addJS($this->_path . 'views/js/captcha_newsletter.js');
        }

        // Check and display captcha contact Javascript
        if ($this->context->controller instanceof ContactController) {
            if ($captcha_contact) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }

                $this->context->controller->addJS($this->_path . 'views/js/captcha_contact.js');
            }
        }

        // Check and display captcha login Javascript
        // Check if fail customer login attemps exceded
        if (Configuration::get('RECAPTCHAPRO_FAIL_LOGINA') != 0 && $captcha_frontend == true) {
            $cookie_n = new Cookie('register_us');
        }
        if (Tools::getIsset('submitLogin') || Tools::getIsset('SubmitLogin')) {
            if (Configuration::get('RECAPTCHAPRO_FAIL_LOGINA') != 0 && $captcha_frontend == true) {
                if ($cookie_n->__isset('pbfa')) {
                    if ($cookie_n->pbfa_e < time()) {
                        $expiry = time() + 600;
                        $cookie_n->__set('pbfa', '1');
                        $cookie_n->__set('pbfa_e', $expiry);
                    } else {
                        $cookie_n->__set('pbfa', $cookie_n->pbfa + 1);
                    }
                } else {
                    $expiry = time() + 600;
                    $cookie_n->__set('pbfa', '1');
                    $cookie_n->__set('pbfa_e', $expiry);

                    $captcha_frontend = true;
                }
            }
        }
        if (Configuration::get('RECAPTCHAPRO_FAIL_LOGINA') != 0 && $captcha_frontend == true) {
            if ($cookie_n->__isset('pbfa')) {
                if ($cookie_n->pbfa_e < time()) {
                    $expiry = time() + 600;
                    $cookie_n->__set('pbfa', '1');
                    $cookie_n->__set('pbfa_e', $expiry);

                    if ($cookie_n->pbfa < Configuration::get('RECAPTCHAPRO_FAIL_LOGINA')) {
                        $captcha_frontend = false;
                    } else {
                        $captcha_frontend = true;
                    }
                } else {
                    if ($cookie_n->pbfa < Configuration::get('RECAPTCHAPRO_FAIL_LOGINA')) {
                        $captcha_frontend = false;
                    } else {
                        $captcha_frontend = true;
                    }
                }
            } else {
                $captcha_frontend = false;
            }
        }
        if ($this->context->controller instanceof AuthController) {
            if ($captcha_frontend || $captcha_registration) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }

                if ($captcha_frontend) {
                    $this->context->controller->addJS($this->_path . 'views/js/captcha_login.js');
                }
            }
        }

        // Check and load captcha assets on the Registration Page
        if ($this->context->controller instanceof RegistrationController) {
            if ($captcha_registration) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }
            }
        }

        // Check and load captcha assets on the Order Page and Registration Page
        if ($this->context->controller instanceof OrderController) {
            if ($captcha_registration) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }
            }
        }

        // Check and display captcha forgot password Javascript
        if ($this->context->controller instanceof PasswordController) {
            if ($captcha_resetp) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }

                $this->context->controller->addJS($this->_path . 'views/js/captcha_resetp.js');
            }
        }

        // Check and display captcha comments Javascript
        if ($this->context->controller instanceof ProductController) {
            if ($captcha_comments) {
                if (!$captcha_newsletter) {
                    $this->loadRecaptchaAssets();
                }

                $this->context->controller->addJS($this->_path . 'views/js/captcha_comments.js');
            }
        }

        if (Tools::substr(_PS_VERSION_, 0, 3) == '1.5') {
            return $this->context->smarty->fetch($this->local_path . 'views/templates/front/java_front.tpl');
        }
    }

    /**
     * Add content on Registration Form Area
     */
    public function hookCreateAccountForm()
    {
        $captcha_enable = explode(';', Configuration::get('RECAPTCHAPRO_ENABLE_FOR'));

        foreach ($captcha_enable as $each_e) {
            if ($each_e == 4) {
                if ($this->checkIfWhitelisted()) {
                    return Configuration::get('RECAPTCHAPRO_WHITELISTMESSAGE', $this->context->language->id);
                }

                if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                    // Add all Javascript global variables
                    Media::addJsDef(
                        [
                            'p_version' => Tools::substr(_PS_VERSION_, 0, 3),
                            'p_version_short' => Tools::substr(_PS_VERSION_, 0, 1),
                        ]
                    );
                } else {
                    $this->context->smarty->assign(
                        [
                            'p_version' => Tools::substr(_PS_VERSION_, 0, 3),
                        ]
                    );
                }

                // Prepeare smarty assign
                $assign = [
                    'there_is1' => $this->l('There is 1 error'),
                    'wrong_captcha' => $this->l('Wrong captcha.'),
                    'site_key' => Configuration::get('RECAPTCHAPRO_SITE_KEY'),
                    're_version' => Configuration::get('RECAPTCHAPRO_RECAPTCHAV'),
                    're_theme' => Configuration::get('RECAPTCHAPRO_RETHEME'),
                    're_size' => Configuration::get('RECAPTCHAPRO_RESIZE'),
                    're_position' => Configuration::get('RECAPTCHAPRO_POSITION'),
                ];

                $this->context->smarty->assign($assign);

                if (Tools::substr(_PS_VERSION_, 0, 3) == '1.5') {
                    return $this->context->smarty->fetch($this->local_path . 'views/templates/front/register.tpl');
                } else {
                    return $this->display(__FILE__, 'register.tpl');
                }
            }
        }

        return false;
    }

    /**
     * Add content on Admin Login Area
     */
    public function hookActionAdminLoginControllerSetMedia()
    {
        if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
            $captcha_enable = explode(';', Configuration::get('RECAPTCHAPRO_ENABLE_FOR'));

            foreach ($captcha_enable as $each_e) {
                if ($each_e == 2) {
                    if (!$this->checkIfWhitelisted()) {
                        Media::addJsDef(
                            [
                                're_version' => Configuration::get('RECAPTCHAPRO_RECAPTCHAV'),
                                'there_is1' => $this->l('There is 1 error'),
                                'wrong_captcha' => $this->l('Wrong captcha.'),
                                'site_key' => Configuration::get('RECAPTCHAPRO_SITE_KEY'),
                                're_theme' => Configuration::get('RECAPTCHAPRO_RETHEME'),
                                're_language' => $this->registerLanguage(Configuration::get('RECAPTCHAPRO_RELANGUAGE')),
                                're_size' => Configuration::get('RECAPTCHAPRO_RESIZE'),
                                're_position' => Configuration::get('RECAPTCHAPRO_POSITION'),
                                'p_version_short' => Tools::substr(_PS_VERSION_, 0, 1),
                            ]
                        );

                        if (Tools::getIsset('logout')) {
                            $link = $this->context->link->getAdminLink('AdminLogin');
                            Tools::redirectAdmin($link);
                        }

                        $this->context->controller->addJS('https://www.google.com/recaptcha/api.js?hl=' . $this->registerLanguage(Configuration::get('RECAPTCHAPRO_RELANGUAGE')));
                        $this->context->controller->addJS($this->local_path . 'views/js/admin_footer.js');
                    }
                }
            }
        }
    }

    /**
     * Validate inputs from all forms
     */
    public function hookActionDispatcher($params)
    {
        $captcha_enable = explode(';', Configuration::get('RECAPTCHAPRO_ENABLE_FOR'));
        $captcha_contact = false;
        $captcha_frontend = false;
        $captcha_register = false;
        $captcha_resetp = false;
        $captcha_newsletter = false;

        foreach ($captcha_enable as $each_e) {
            switch ($each_e) {
                case 1:
                    $captcha_contact = true;
                    break;
                case 3:
                    $captcha_frontend = true;
                    break;
                case 4:
                    $captcha_register = true;
                    break;
                case 5:
                    $captcha_resetp = true;
                    break;
                case 7:
                    $captcha_newsletter = true;
                    break;
            }
        }

        // Recheck $captcha_frontend
        if (Configuration::get('RECAPTCHAPRO_FAIL_LOGINA') != 0 && $captcha_frontend == true) {
            $cookie_n = new Cookie('register_us');
            if ($cookie_n->__isset('pbfa')) {
                if ($cookie_n->pbfa_e < time()) {
                    $expiry = time() + 600;
                    $cookie_n->__set('pbfa', '1');
                    $cookie_n->__set('pbfa_e', $expiry);

                    if ($cookie_n->pbfa < Configuration::get('RECAPTCHAPRO_FAIL_LOGINA')) {
                        $captcha_frontend = false;
                    } else {
                        $captcha_frontend = true;
                    }
                } else {
                    if ($cookie_n->pbfa < Configuration::get('RECAPTCHAPRO_FAIL_LOGINA')) {
                        $captcha_frontend = false;
                    } else {
                        $captcha_frontend = true;
                    }
                }
            } else {
                $captcha_frontend = false;
            }
        }

        // Check captchapro on contact page
        $this->captchaValidator('ContactController', $captcha_contact, 'submitMessage', 'submitMessage', $this, 0);

        if (Tools::substr(_PS_VERSION_, 0, 3) == '1.7' || Tools::substr(_PS_VERSION_, 0, 1) == '8') {
            // Check captchapro on login page
            $this->captchaValidator('AuthController', $captcha_frontend, 'submitLogin', 'submitLogin', $this, 0);

            // Check captchapro on register page
            if (!$this->checkIfWhitelisted()) {
                $this->captchaValidator('AuthController', $captcha_register, 'submitCreate', 'submitCreate', $this, 0);
            }

            // Check captchapro on forgot password page
            $this->captchaValidator('PasswordController', $captcha_resetp, 'email', 'email', $this, 0);

            // Check captchapro on newsletter page
            $this->captchaValidator('', $captcha_newsletter, 'submitNewsletter', 'submitNewsletter', $this, 1);
        } elseif (Tools::substr(_PS_VERSION_, 0, 3) == '1.6') {
            // Check captchapro on register page
            if (!$this->checkIfWhitelisted()) {
                $this->captchaValidator('AuthController', $captcha_register, 'submitAccount', 'submitAccount', $this, 0);
            }

            // Check captchapro on forgot password page
            $this->captchaValidator('PasswordController', $captcha_resetp, 'email', 'email', $this, 0);

            // Check captchapro on newsletter page
            $this->captchaValidator('', $captcha_newsletter, 'submitNewsletter', 'submitNewsletter', $this, 1);
        } elseif (Tools::substr(_PS_VERSION_, 0, 3) == '1.5') {
            // Check captchapro on login page
            $this->captchaValidator('AuthController', $captcha_frontend, 'SubmitLogin', 'SubmitLogin', $this, 0);

            // Check captchapro on register page
            if (!$this->checkIfWhitelisted()) {
                $this->captchaValidator('AuthController', $captcha_register, 'submitAccount', 'submitAccount', $this, 0);
            }

            // Check captchapro on forgot password page
            $this->captchaValidator('PasswordController', $captcha_resetp, 'email', 'email', $this, 0);

            // Check captchapro on newsletter page
            $this->captchaValidator('', $captcha_newsletter, 'submitNewsletter', 'submitNewsletter', $this, 1);
        }
    }

    /**
     * Load necessary assets for reCaptcha in Frontend
     */
    protected function loadRecaptchaAssets()
    {
        if (Tools::substr(_PS_VERSION_, 0, 3) == '1.7' || Tools::substr(_PS_VERSION_, 0, 1) == '8') {
            $this->context->controller->registerJavascript(
                'remote-recaptcha-api',
                'https://www.google.com/recaptcha/api.js?hl=' . $this->registerLanguage(Configuration::get('RECAPTCHAPRO_RELANGUAGE')),
                ['server' => 'remote', 'position' => 'bottom', 'priority' => 200]
            );
        } else {
            $this->context->controller->addJS('https://www.google.com/recaptcha/api.js?hl=' . $this->registerLanguage(Configuration::get('RECAPTCHAPRO_RELANGUAGE')));
        }
        $this->context->controller->addJS($this->_path . 'views/js/front.js');
        $this->context->controller->addCSS($this->_path . 'views/css/front.css');
    }

    /**
     * Delete ips from whitelist table
     */
    protected function deleteWhitelist($pid)
    {
        $sql = 'SELECT id_whitelist FROM ' . _DB_PREFIX_ . 'rec_whitelist WHERE id_whitelist = "' . pSQL($pid) . '"';

        if ($row = Db::getInstance()->getRow($sql)) {
            $id_whitelist = $row['id_whitelist'];

            Db::getInstance()->delete('rec_whitelist', 'id_whitelist = "' . (int) $id_whitelist . '"');
        }
    }

    /**
     * Register the correct language for Smarty display
     */
    protected function registerLanguage($re_language)
    {
        if ($re_language == 1) {
            return $this->context->language->iso_code;
        } elseif ($re_language == 2) {
            return Configuration::get('RECAPTCHAPRO_CUSTOMLANGUAGE');
        } else {
            return 'en';
        }
    }

    /**
     * Check if Whitelisted
     */
    protected function checkIfWhitelisted()
    {
        $public_ip = '';
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $public_ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $public_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
            $public_ip = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
            $public_ip = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
            $public_ip = $_SERVER['HTTP_FORWARDED'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $public_ip = $_SERVER['REMOTE_ADDR'];
        } else {
            $public_ip = 'UNKNOWN';
        }

        if ($public_ip != 'UNKNOWN') {
            $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'rec_whitelist WHERE ip_address = "' .
                pSQL(trim($public_ip)) . '"';
            if (Db::getInstance()->ExecuteS($sql)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    /**
     * Dynamic validator for each form
     */
    public static function captchaValidator($controller_name, $captcha_form, $submit_variable, $unset_variable, $this_c, $no_controller)
    {
        if ((get_class($this_c->context->controller) == $controller_name && $captcha_form) || ($no_controller && $captcha_form)) {
            if (Tools::isSubmit($submit_variable)) {
                if (!Tools::getValue('g-recaptcha-response')) {
                    if (Tools::getValue('g-recaptcha-response') === '') {
                        if (!Tools::getValue('recaptcha_whitelisted')) {
                            if ($no_controller) {
                                if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                                    Media::addJsDef([
                                        'display_error' => 1,
                                        'error_message' => $this_c->l('Wrong captcha.'),
                                    ]);
                                }
                                unset($_POST[$unset_variable]);
                                unset($_GET[$unset_variable]);
                            } else {
                                $this_c->context->controller->errors = [$this_c->l('Wrong captcha.')];
                                unset($_POST[$unset_variable]);
                                unset($_GET[$unset_variable]);
                            }
                        }
                    } else {
                        if (Tools::getValue('invisible-g-recaptcha-response') === '') {
                        } else {
                            if (!Tools::getValue('recaptcha_whitelisted')) {
                                if ($no_controller) {
                                    if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                                        Media::addJsDef([
                                            'display_error' => 1,
                                            'error_message' => $this_c->l('Error captcha. Please contact the administrator.'),
                                        ]);
                                    }
                                    unset($_POST[$unset_variable]);
                                    unset($_GET[$unset_variable]);
                                } else {
                                    $this_c->context->controller->errors = [$this_c->l('Error captcha. Please contact the administrator.')];
                                    unset($_POST[$unset_variable]);
                                    unset($_GET[$unset_variable]);
                                }
                            }
                        }
                    }
                } else {
                    $post_data = http_build_query(
                        [
                            'secret' => Configuration::get('RECAPTCHAPRO_SECRET_KEY'),
                            'response' => Tools::getValue('g-recaptcha-response'),
                            'remoteip' => $_SERVER['REMOTE_ADDR'],
                        ]
                    );

                    $opts = ['http' => [
                            'method' => 'POST',
                            'header' => 'Content-type: application/x-www-form-urlencoded',
                            'content' => $post_data,
                        ],
                    ];

                    $context = stream_context_create($opts);
                    $response = Tools::file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
                    $result = json_decode($response);

                    if ($result) {
                        if ($result->success == true) {
                            if (isset($result->score)) {
                                if ($result->score < Configuration::get('RECAPTCHAPRO_THRESHOLD')) {
                                    if ($no_controller) {
                                        if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                                            Media::addJsDef([
                                                'display_error' => 1,
                                                'error_message' => $this_c->l('Captcha error: Your reCaptcha score is below the minimum score required in order to pass the validation. Please contact the administrator.'),
                                            ]);
                                        }
                                        unset($_POST[$unset_variable]);
                                        unset($_GET[$unset_variable]);
                                    } else {
                                        $this_c->context->controller->errors = [$this_c->l('Captcha error: Your reCaptcha score is below the minimum score required in order to pass the validation. Please contact the administrator.')];
                                        unset($_POST[$unset_variable]);
                                        unset($_GET[$unset_variable]);
                                    }
                                }
                            } else {
                                // User is validated successfully, no action required to block it
                            }
                        } else {
                            if ($no_controller) {
                                if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                                    Media::addJsDef([
                                        'display_error' => 1,
                                        'error_message' => $this_c->l('Captcha error: ') . $result->{'error-codes'}[0],
                                    ]);
                                }
                                unset($_POST[$unset_variable]);
                                unset($_GET[$unset_variable]);
                            } else {
                                $this_c->context->controller->errors = [$this_c->l('Captcha error: ') . $result->{'error-codes'}[0]];
                                unset($_POST[$unset_variable]);
                                unset($_GET[$unset_variable]);
                            }
                        }
                    } else {
                        if ($no_controller) {
                            if (Tools::substr(_PS_VERSION_, 0, 3) != '1.5') {
                                Media::addJsDef([
                                    'display_error' => 1,
                                    'error_message' => $this_c->l('Captcha error: ') . $result->{'error-codes'}[0],
                                ]);
                            }
                            unset($_POST[$unset_variable]);
                            unset($_GET[$unset_variable]);
                        } else {
                            $this_c->context->controller->errors = [$this_c->l('Captcha error: ') . $result->{'error-codes'}[0]];
                            unset($_POST[$unset_variable]);
                            unset($_GET[$unset_variable]);
                        }
                    }
                }
            }
        }
    }
}
