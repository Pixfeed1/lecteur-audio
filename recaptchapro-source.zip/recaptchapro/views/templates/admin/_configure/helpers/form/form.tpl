{**
 * 2007-2023 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2023 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 *}

{extends file="helpers/form/form.tpl"}
{block name="field"}
    {if isset($input.class)}
        {if $input.class == 'resitekey'}
            <div class="{if $version_explicit == '1.7.8' || $version_explicit_one == '8'}col-lg-8{else}col-lg-9{/if}">
                <input type="text" name="{$input.name|escape:'html':'UTF-8'}" id="{$input.name|escape:'html':'UTF-8'}" value="{$fields_value[$input.name]|escape:'html':'UTF-8'}" required="required">
                <p class="help-block">{l s='Register your website with Google to get required API keys and enter them below.' mod='recaptchapro'} <a href="https://www.google.com/recaptcha/admin#list" target="_blank">{l s='Get the API Keys' mod='recaptchapro'}</a></p>
            </div>
        {else if $input.class == 'r_threshold'}
            <div class="{if $version_explicit == '1.7.8' || $version_explicit_one == '8'}col-lg-8{else}col-lg-9{/if} {if $input.version == '1.5'}margin-form{/if}">
                <div class="re-range-slider" id="{$input.name|escape:'html':'UTF-8'}">
                    <input class="re-range-slider__range" type="range" name="{$input.name|escape:'html':'UTF-8'}" value="{$fields_value[$input.name]|escape:'html':'UTF-8'}" min="0" max="1" step="0.1">
                    {if $input.version != '1.5'}
                        <span class="re-range-slider__value">0</span>
                    {/if}
                </div>
                <p class="help-block help-bslider">{l s='reCAPTCHA v3 returns a score (0.0 is very likely a bot, 1.0 is very likely a good interaction). With this option, you can set the minimum score required in order to pass the validation.' mod='recaptchapro'} <a href="https://developers.google.com/recaptcha/docs/v3#interpreting_the_score" target="_blank">{l s='Learn more' mod='recaptchapro'}</a></p>
            </div>
        {else}
            {$smarty.block.parent}
        {/if}
    {else}
        {$smarty.block.parent}
    {/if}
{/block}