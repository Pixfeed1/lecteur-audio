/**
 * 2007-2023 PrestaShop
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License (AFL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/afl-3.0.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@prestashop.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade PrestaShop to newer
 * versions in the future. If you wish to customize PrestaShop for your
 * needs please refer to http://www.prestashop.com for more information.
 *
 *  @author    PrestaShop SA <contact@prestashop.com>
 *  @copyright 2007-2023 PrestaShop SA
 *  @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 *  International Registered Trademark & Property of PrestaShop SA
 *
 * Don't forget to prefix your containers with your own identifier
 * to avoid any conflicts with others containers.
 */

// Vanilla document ready
document.addEventListener('DOMContentLoaded', function() {
	if (site_key) {
		if (! $('.g-recaptcha').length) {
			// Create structure variables
			var submit_button = findCM([
				'#login-panel #login_form button[name="submitLogin"]'
			]);
			var login_form = findCM([
				'#login-panel #login_form'
			]);
			var captcha_position = findCM([
				'#login-panel #login_form .form-group:nth-child(3)'
			]);
			var error_header = findCM([
				'#login #login-header div.text-center'
			]);
			
			// Fix the form-footer margin
			if (p_version_short != '8') {
				$('#login-footer').css('margin-top', '70px');
			}
			
			// Add our captcha depending to reCaptcha version
			if (re_version == 1) {
				// reCaptcha Version 2 Checkbox
				$(captcha_position).after('<div class="g-recaptcha" data-sitekey="' + site_key + '" data-theme="' + re_theme + '" data-size="' + re_size + '"></div>');
				
				var clicked_first = true;
				
				$(submit_button).on('click', function() {
					if (clicked_first == true) {
						if ($(submit_button).prop('type') == 'submit') {
							$(submit_button).prop('type', 'button');
						}
					}
					
					if (clicked_first == true) {
						if (grecaptcha.getResponse()) {
							$(submit_button).prop('type', 'submit');
							clicked_first = false;
							$(submit_button).click();
						} else {
							$('.captcha-alert').remove();
							$('<div class="alert alert-danger error captcha-alert" id="error"><p>' + there_is1 + '</p><ol><li>' + wrong_captcha + '</ol></div>').hide().insertAfter(error_header).fadeIn(600);
						}
					}
				});
			} else if (re_version == 2 || re_version == 3) {
				// reCaptcha Version 2 Invisible and Version 3
				regCM(submit_button, login_form, error_header);
				
				$(submit_button).click(function(event) {
					if (! grecaptcha.getResponse()) {
						event.preventDefault();
						grecaptcha.execute();
					}
				});
				
				if (re_position == 'inline') {
					$(captcha_position).after('<div id="recaptcha" class="g-recaptcha" data-sitekey="' + site_key + '" data-callback="onreCSubmit" data-size="invisible" data-badge="inline"></div>');
				} else {
					$('#login-panel').append('<div id="recaptcha" class="g-recaptcha" data-sitekey="' + site_key + '" data-callback="onreCSubmit" data-size="invisible" data-badge="bottom' + re_position + '"></div>');
				}
			
				$(submit_button).attr('type', 'button');
			}
		}
	}
});

// Utility functions
function onreCSubmit(token) {
	if (token) {
		$($('#re_submit_button').attr('data-parameter')).attr('type', 'submit');
		$($('#re_login_form').attr('data-parameter')).submit();
	}
}

function findCM(str) {
	var temp = false;
	
	$.each(str, function(key, value) {
		if ($(value).length) {
			temp = value;
			return false;
		}
	});
	
	if (temp) {
		return temp;   
	} else {
		return false;
	}
}

function regCM(submit_button, login_form, error_header) {
	$('body').append("<div id='re_error_header' data-parameter='" + error_header + "'></div>");
	$('body').append("<div id='re_submit_button' data-parameter='" + submit_button + "'></div>");
	$('body').append("<div id='re_login_form' data-parameter='" + login_form + "'></div>");
}